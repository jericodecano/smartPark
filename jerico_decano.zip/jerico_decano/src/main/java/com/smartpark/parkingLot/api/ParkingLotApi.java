package com.smartpark.parkingLot.api;

import com.smartpark.model.ParkingLot;
import com.smartpark.model.ParkingLots;

public interface ParkingLotApi {

	ParkingLots getParkingLots();
	
	ParkingLot addParkingLot(ParkingLot parkingLot);
	
	//String getParkingLotByLotId(String lotId);
	
	ParkingLot getParkingLotByLotId(ParkingLot parkingLot);
}
