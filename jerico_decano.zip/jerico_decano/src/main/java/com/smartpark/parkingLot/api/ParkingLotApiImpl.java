package com.smartpark.parkingLot.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartpark.model.ParkingLot;
import com.smartpark.model.ParkingLots;
import com.smartpark.model.Vehicles;
import com.smartpark.parkingLot.service.ParkingLotService;

@RestController
@RequestMapping(path = "/parkingLot")
public class ParkingLotApiImpl implements ParkingLotApi{

	@Autowired
	ParkingLotService parkingLotService;
	
	// Implementing a GET method 
    // to get the list of all 
    // the parking lots
	@Override
	@GetMapping( 
	        path = "/getParkingLots", 
	        produces = "application/json")
	public ParkingLots getParkingLots() {
		// TODO Auto-generated method stub
		return parkingLotService.getParkingLots();
	}

	// Implementing a POST method 
    // to add to 
    // the parking lots
	@Override
	@PostMapping( 
	        path = "/addParkingLot", 
	        consumes = "application/json", 
	        produces = "application/json")
	public ParkingLot addParkingLot(@RequestBody ParkingLot parkingLot) {
		// TODO Auto-generated method stub
		return parkingLotService.addParkingLot(parkingLot);
	}

	/*@Override
	@GetMapping( 
	        path = "/getParkingLotByLotId/", 
	        produces = "application/json")
	public String getParkingLotByLotId(@RequestParam("lotId") String lotId) {
		// TODO Auto-generated method stub
		ParkingLot parkingLot = parkingLotService.getParkingLotByLotId(lotId);
		
		String message = "LOT ID: " + parkingLot.getLotId() + "\n" 
		+ "CURRENT OCCUPANCY: " + parkingLot.getOccupiedSpaces() + "\n"
		+ "AVAILABILITY: " + String.valueOf(parkingLot.getCapacity() - parkingLot.getOccupiedSpaces());
		
		return message;
	}*/
	
	@Override
	@PostMapping( 
	        path = "/getParkingLotByLotId", 
	        consumes = "application/json", 
	        produces = "application/json")
	public ParkingLot getParkingLotByLotId(@RequestBody ParkingLot parkingLot) {
		// TODO Auto-generated method stub
		ParkingLot parkingLotTemp = parkingLotService.getParkingLotByLotId(parkingLot.getLotId());
		
		if (null != parkingLotTemp.getLotId()) {
			parkingLot = parkingLotTemp;
		}else {
			parkingLot.setComment(parkingLotTemp.getComment());
		}
		
		return parkingLot;
	}
}
