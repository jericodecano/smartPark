package com.smartpark.parkingLot.repository;

import java.math.BigDecimal;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.smartpark.model.ParkingLot;
import com.smartpark.model.ParkingLots;

@Repository
public class ParkingLotDAO {
	
	private static ParkingLots list = new ParkingLots();
	
	/*
	static {
		list.getParkingLotList().add(
				new ParkingLot(
						"LOT ID MOJ",
						"EL PUEBLO",
						100,
						20,
						new BigDecimal(600D)
						));
		
		list.getParkingLotList().add(
				new ParkingLot(
						"LOT ID JEC",
						"EL PUEBLO",
						100,
						20,
						new BigDecimal(800D)
						));
		
		list.getParkingLotList().add(
				new ParkingLot(
						"LOT ID SMALL",
						"EL PUEBLO",
						10,
						10,
						new BigDecimal(10000D)
						));
	}
	*/
	
	public ParkingLots getAllParkingLots() {
		return list;
	}
	
	public void addParkingLot(ParkingLot parkingLot) {
		list.getParkingLotList().add(parkingLot);
	}
	
	public ParkingLot getParkingLotByLotId(String lotId) {
		ParkingLot parkingLot = null;
		Optional<ParkingLot> tempParkingLot = list.getParkingLotList().stream()
				.filter(x -> lotId.equals(x.getLotId())).findFirst();
		
		if (tempParkingLot.isPresent()) {
			parkingLot = tempParkingLot.get();
		}
		
		return parkingLot;
	}

}
