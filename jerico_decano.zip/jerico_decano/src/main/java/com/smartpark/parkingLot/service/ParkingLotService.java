package com.smartpark.parkingLot.service;

import org.springframework.http.ResponseEntity;

import com.smartpark.model.ParkingLot;
import com.smartpark.model.ParkingLots;
import com.smartpark.model.Vehicles;

public interface ParkingLotService {

	ParkingLots getParkingLots();
	
	ParkingLot addParkingLot(ParkingLot parkingLot);
	
	ParkingLot getParkingLotByLotId(String lotId);
	
	void updateParkingLotOccupiedSpaces(ParkingLot parkingLot);
}
