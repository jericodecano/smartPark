package com.smartpark.parkingLot.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.smartpark.model.ParkingLot;
import com.smartpark.model.ParkingLots;
import com.smartpark.parkingLot.repository.ParkingLotDAO;

@Service
public class ParkingLotServiceImpl implements ParkingLotService{

	@Autowired
	private ParkingLotDAO parkingLotDAO;
	
	@Override
	public ParkingLots getParkingLots() {
		// TODO Auto-generated method stub
		return parkingLotDAO.getAllParkingLots();
	}

	@Override
	public ParkingLot addParkingLot(ParkingLot parkingLot) {
		try {
			// TODO Auto-generated method stub
			if (null == parkingLot.getLotId()) {
				parkingLot.setStatus("FAILED");
				parkingLot.setComment(
						"LOT ID IS REQUIRED");
				
				return parkingLot;
			}
			
			if (50 < parkingLot.getLotId().length()) {
				parkingLot.setStatus("FAILED");
				parkingLot.setComment(
						"LOT ID TOO LONG. MAXIMUM OF 50 CHARACTERS ONLY");
				
				return parkingLot;
			}
			
			ParkingLot tempParkingLot = parkingLotDAO.getParkingLotByLotId(parkingLot.getLotId());
			
			if (null != tempParkingLot) {
				parkingLot.setStatus("FAILED");
				parkingLot.setComment(
						"PARKING LOT WITH LOT ID - " + parkingLot.getLotId() + " IS ALREADY REGISTERED");
				
				return parkingLot;
			}
			
			Integer id = parkingLotDAO.getAllParkingLots().getParkingLotList().size() + 1;
			
			parkingLot.setId(id);
			parkingLot.setCurrentDate(new Date());
			parkingLot.setStatus("SUCCESS");
			parkingLot.setComment(
					"PARKING LOT WITH LOT ID - " + parkingLot.getLotId() + " IS REGISTERED SUCCESSFULLY");
			
			parkingLotDAO.getAllParkingLots().getParkingLotList().add(parkingLot);
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			parkingLot.setStatus("FAILED");
			parkingLot.setComment(
					"PARKING LOT WITH LOT ID - " + parkingLot.getLotId() + " - REGISTRATION FAILED");
		}
		
		return parkingLot;
	}

	@Override
	public ParkingLot getParkingLotByLotId(String lotId) {
		// TODO Auto-generated method stub
		String param = lotId.trim();
		ParkingLot tempParkingLot = new ParkingLot();
		ParkingLot result = parkingLotDAO.getParkingLotByLotId(param);
		
		if (null != result) {
			tempParkingLot = result;
			tempParkingLot.setAvailability(tempParkingLot.getCapacity() - tempParkingLot.getOccupiedSpaces());
		}else {
			tempParkingLot.setComment("PARKING LOT NOT FOUND.");
		}
		
		return tempParkingLot;
	}

	@Override
	public void updateParkingLotOccupiedSpaces(ParkingLot parkingLot) {
		// TODO Auto-generated method stub
		for (ParkingLot parking : parkingLotDAO.getAllParkingLots().getParkingLotList()) {
			if (parkingLot.getLotId().equals(parking.getLotId())) {
				parking.setOccupiedSpaces(parkingLot.getOccupiedSpaces());
				break;
			}
		}
	}
}
