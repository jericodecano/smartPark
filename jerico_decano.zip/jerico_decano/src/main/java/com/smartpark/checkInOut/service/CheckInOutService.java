package com.smartpark.checkInOut.service;

import com.smartpark.model.CheckInVehicle;
import com.smartpark.model.CheckInVehicleRequest;
import com.smartpark.model.CheckInVehicles;
import com.smartpark.model.Vehicles;

public interface CheckInOutService {
	
	CheckInVehicles getAllCheckedIn();
	
	CheckInVehicleRequest checkInVehicle(CheckInVehicleRequest checkInRequest);
	
	CheckInVehicle checkOutVehicle(String licensePlate);
	
	Vehicles getAllVehiclesInALot(String lotId);

}
