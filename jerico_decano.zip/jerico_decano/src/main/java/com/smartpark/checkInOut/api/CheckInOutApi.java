package com.smartpark.checkInOut.api;

import com.smartpark.model.CheckInVehicle;
import com.smartpark.model.CheckInVehicleRequest;
import com.smartpark.model.CheckInVehicles;
import com.smartpark.model.ParkingLot;
import com.smartpark.model.Vehicles;

public interface CheckInOutApi {
	
	CheckInVehicles getAllCheckedIn();
	
	CheckInVehicleRequest checkInVehicle(CheckInVehicleRequest checkInRequest);
	
	CheckInVehicle checkOutVehicle(CheckInVehicleRequest checkInRequest);
	
	Vehicles getAllVehiclesInALot(ParkingLot parkingLot);

}
