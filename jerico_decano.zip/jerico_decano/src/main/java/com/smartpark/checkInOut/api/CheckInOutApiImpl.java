package com.smartpark.checkInOut.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartpark.checkInOut.service.CheckInOutService;
import com.smartpark.model.CheckInVehicle;
import com.smartpark.model.CheckInVehicleRequest;
import com.smartpark.model.CheckInVehicles;
import com.smartpark.model.ParkingLot;
import com.smartpark.model.Vehicle;
import com.smartpark.model.Vehicles;

@RestController
@RequestMapping(path = "/checkInOut")
public class CheckInOutApiImpl implements CheckInOutApi{
	
	@Autowired
	CheckInOutService checkInOutService;
	
	// Implementing a GET method 
    // to get the list of all 
    // checked in
	@Override
	@GetMapping( 
	        path = "/checkedIn", 
	        produces = "application/json")
	public CheckInVehicles getAllCheckedIn() {
		// TODO Auto-generated method stub
		return checkInOutService.getAllCheckedIn();
	}

	@PostMapping( 
	        path = "/checkInVehicle", 
	        consumes = "application/json", 
	        produces = "application/json")
	@Override
	public CheckInVehicleRequest checkInVehicle(@RequestBody CheckInVehicleRequest checkInRequest) {
		// TODO Auto-generated method stub
		
		return checkInOutService.checkInVehicle(checkInRequest);
	}

	@Override
	@PostMapping( 
	        path = "/checkOutVehicle", 
    		consumes = "application/json", 
	        produces = "application/json")
	public CheckInVehicle checkOutVehicle(@RequestBody CheckInVehicleRequest checkInRequest) {
		// TODO Auto-generated method stub
		CheckInVehicle checkOut = checkInOutService.checkOutVehicle(checkInRequest.getLicensePlate());
		
		return checkOut;
	}
	
	@Override
	@PostMapping( 
	        path = "/getAllVehiclesInALot", 
    		consumes = "application/json", 
	        produces = "application/json")
	public Vehicles getAllVehiclesInALot(@RequestBody ParkingLot parkingLot) {
		// TODO Auto-generated method stub
		Vehicles checkInVehicles = checkInOutService.getAllVehiclesInALot(parkingLot.getLotId());
		
		return checkInVehicles;
	}
}
