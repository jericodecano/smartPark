package com.smartpark.checkInOut.repository;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.smartpark.model.CheckInVehicle;
import com.smartpark.model.CheckInVehicles;

@Repository
public class CheckInOutDAO {
	
	private static CheckInVehicles checkInList = new CheckInVehicles();
	
	static {
		/*checkInList.getCheckInVehicleList().add(
				new CheckInVehicle(
						new Vehicle(
								"LICENSCE INSERT", null, null
								), 
						new ParkingLot("LOT NO PARKING LOT", null, 0, 0, null)
						)
				);*/
	}

	public CheckInVehicles getCheckInList() {
		return checkInList;
	}

	public void checkInVehicle(CheckInVehicle checkIn) {
		checkInList.getCheckInVehicleList().add(checkIn);
	};
	
	public CheckInVehicle findCheckedInVehicle(String licensePlate) {
		CheckInVehicle checkedIn = null;
		
		Optional<CheckInVehicle> tempCheckedIn = checkInList.getCheckInVehicleList().stream()
				.filter(x -> licensePlate.equals(x.getVehicle().getLicensePlate())
						&& !x.getIsCheckedOut()).findFirst();
		
		if (tempCheckedIn.isPresent()) {
			checkedIn = tempCheckedIn.get();
		}
		
		return checkedIn;
	}
	
	public CheckInVehicles findCheckedInVehiclesByLotId(String lotId) {
		CheckInVehicles checkInByLotId = new CheckInVehicles();
		
		for (CheckInVehicle checkIn : checkInList.getCheckInVehicleList()) {
			if (checkIn.getIsCheckedOut()) {
				continue;
			}
			
			String tempLotId = checkIn.getParkingLot().getLotId();
			
			if (lotId.equals(tempLotId)) {
				checkInByLotId.getCheckInVehicleList().add(checkIn);
			}
		}
		
		return checkInByLotId;
	}
	
}
