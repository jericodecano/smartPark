package com.smartpark.checkInOut.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.smartpark.checkInOut.repository.CheckInOutDAO;
import com.smartpark.model.CheckInVehicle;
import com.smartpark.model.CheckInVehicleRequest;
import com.smartpark.model.CheckInVehicles;
import com.smartpark.model.ParkingLot;
import com.smartpark.model.Vehicle;
import com.smartpark.model.Vehicles;
import com.smartpark.parkingLot.service.ParkingLotServiceImpl;
import com.smartpark.vehicle.service.VehicleService;

@Service
public class CheckInOutServiceImpl implements CheckInOutService{

	@Autowired
	VehicleService vehicleService;
	
	@Autowired
	ParkingLotServiceImpl parkingLotService;
	
	@Autowired
	CheckInOutDAO checkInOutDAO;
	
	@Override
	public CheckInVehicles getAllCheckedIn() {
		// TODO Auto-generated method stub
		return checkInOutDAO.getCheckInList();
	}
	
	@Override
	public CheckInVehicleRequest checkInVehicle(CheckInVehicleRequest checkInRequest) {
		// TODO Auto-generated method stub
		automaticRemoveOfVehicles();
		
		Vehicle vehicle = vehicleService.getVehicleByLicensePlate(checkInRequest.getLicensePlate());
		ParkingLot parkingLot = parkingLotService.getParkingLotByLotId(checkInRequest.getLotId());
		
		if (parkingLot.getCapacity() == parkingLot.getOccupiedSpaces()) {
			checkInRequest.setComment(
					"LOT: " + parkingLot.getLotId() 
					+ " ALREADY FULL. PLEASE FIND ANOTHER PARKING LOT.");
			
			return checkInRequest;
		}
		
		CheckInVehicle currentCheckIn = checkInOutDAO.findCheckedInVehicle(checkInRequest.getLicensePlate());
		
		if (null != currentCheckIn) {
			checkInRequest.setComment(
					"VEHICLE WITH LICENSE PLATE " + checkInRequest.getLicensePlate() 
					+ " ALREADY IN A PARKING LOT.");
			
			return checkInRequest;
		}
		
		CheckInVehicle checkIn = new CheckInVehicle(vehicle, parkingLot);
		
		Integer id = checkInOutDAO.getCheckInList().getCheckInVehicleList().size();
		
		checkIn.setId(id);
		checkIn.setCurrentDate(new Date());
		checkIn.setCheckIn(checkIn.getCurrentDate());
		
		checkInOutDAO.checkInVehicle(checkIn);
		
		parkingLot.setOccupiedSpaces(parkingLot.getOccupiedSpaces() + 1);
		
		parkingLotService.updateParkingLotOccupiedSpaces(parkingLot);
		
		checkInRequest.setComment(
				"VEHICLE WITH LICENSE PLATE " + checkInRequest.getLicensePlate() 
				+ " NOW PARKED IN " + checkInRequest.getLotId() + " PARKING LOT.");
		
		return checkInRequest;
	}

	@Override
	public CheckInVehicle checkOutVehicle(String licensePlate) {
		//automaticRemoveOfVehicles();
		// TODO Auto-generated method stub
		CheckInVehicle checkInVehicle = checkInOutDAO.findCheckedInVehicle(licensePlate);
		
		if(null != checkInVehicle) {
			ParkingLot parkingLot = parkingLotService.getParkingLotByLotId(checkInVehicle.getParkingLot().getLotId());
			parkingLot.setOccupiedSpaces(parkingLot.getOccupiedSpaces() - 1);
			parkingLotService.updateParkingLotOccupiedSpaces(parkingLot);
			
			checkInVehicle.setIsCheckedOut(true);
			checkInVehicle.setCheckOut(new Date());
			
			long duration = checkInVehicle.getCheckOut().getTime() - checkInVehicle.getCheckIn().getTime();
			long diffInMinutes = TimeUnit.MILLISECONDS.toMinutes(duration);
			
			checkInVehicle.setMinutesOfStay(Math.toIntExact(diffInMinutes));
			
			BigDecimal totalCost = parkingLot.getCostPerMinute().multiply(BigDecimal.valueOf(diffInMinutes));
			checkInVehicle.setTotalCost(totalCost);
		}
		
		return checkInVehicle;
	}

	@Override
	public Vehicles getAllVehiclesInALot(String lotId) {
		automaticRemoveOfVehicles();
		// TODO Auto-generated method stub
		CheckInVehicles checkInVehicles = checkInOutDAO.findCheckedInVehiclesByLotId(lotId);
		Vehicles tempVehicles = new Vehicles();
		
		for (CheckInVehicle checkIn : checkInVehicles.getCheckInVehicleList()) {
			tempVehicles.getVehicleList().add(checkIn.getVehicle());
		}
		
		return tempVehicles;
	}
	
	private void automaticRemoveOfVehicles() {
		CheckInVehicles checkedInVehicles = checkInOutDAO.getCheckInList();
		Date currentDate = new Date();
		
		for (CheckInVehicle checkedIn : checkedInVehicles.getCheckInVehicleList()) {
			if (checkedIn.getIsCheckedOut()) {
				continue;
			}
			
			long duration = currentDate.getTime() - checkedIn.getCheckIn().getTime();
			long diffInMinutes = TimeUnit.MILLISECONDS.toMinutes(duration);
			
			if (5 <= Math.toIntExact(diffInMinutes)) {
				checkOutVehicle(checkedIn.getVehicle().getLicensePlate());
			}
		}
	}
}
