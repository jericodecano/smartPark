package com.smartpark.security;

//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.stereotype.Service;

//import lombok.RequiredArgsConstructor;

//@Service
//@RequiredArgsConstructor
public class UserService {
	
	private final UserRepository userRepository = null;

	/*public UserDetailsService userDetailsService() {
		return new UserDetailsService() {
			@Override
			public UserDetails loadUserByUsername(String username) {
				return userRepository.findByEmail(username).orElseThrow(() 
						-> new UsernameNotFoundException("Username not found."));
			}
		};
	};*/
	
	
}
