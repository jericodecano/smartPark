package com.smartpark.vehicle.api;

import org.springframework.http.ResponseEntity;

import com.smartpark.model.Vehicle;
import com.smartpark.model.Vehicles;

public interface VehicleApi {

	Vehicles getVehicles();
	
	Vehicle addVehicle(Vehicle vehicle);
	
	Vehicle getVehicleByLicensePlate(String licensePlate);
	
}
