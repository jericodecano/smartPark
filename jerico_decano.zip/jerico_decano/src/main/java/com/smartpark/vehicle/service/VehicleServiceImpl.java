package com.smartpark.vehicle.service;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartpark.model.Vehicle;
import com.smartpark.model.Vehicles;
import com.smartpark.vehicle.repository.VehicleDAO;

@Service
public class VehicleServiceImpl implements VehicleService{
	
	@Autowired
	private VehicleDAO vehicleDAO;

	@Override
	public Vehicles getVehicles() {
		// TODO Auto-generated method stub
		return vehicleDAO.getAllVehicles();
	}

	@Override
	public Vehicle addVehicle(Vehicle vehicle) {
		try {
			// TODO Auto-generated method stub
			if (null == vehicle.getLicensePlate()) {
				vehicle.setStatus("FAILED");
				vehicle.setComment(
						"LICENSE PLATE IS REQUIRED");
				
				return vehicle;
			}
			
			if (!isValidLicensePlate(vehicle.getLicensePlate())) {
				vehicle.setStatus("FAILED");
				vehicle.setComment(
						"LICENSE PLATE - " + vehicle.getOwnerName() + " IS NOT ALLOWED. LETTERS, NUMBERS, AND DASH ONLY");
				
				return vehicle;
			}
			
			if (!isAlpha(vehicle.getOwnerName())) {
				vehicle.setStatus("FAILED");
				vehicle.setComment(
						"OWNER NAME - " + vehicle.getOwnerName() + " IS NOT ALLOWED. LETTERS AND SPACES ONLY");
				
				return vehicle;
			}
			
			Vehicle tempVehicle = vehicleDAO.getVehicleByLicensePlate(vehicle.getLicensePlate());
			
			if (null != tempVehicle) {
				vehicle.setStatus("FAILED");
				vehicle.setComment(
						"VEHICLE WITH LICENSE PLATE - " + vehicle.getLicensePlate() + " IS ALREADY REGISTERED.");
				
				return vehicle;
			}
			
			Set<String> vehicleTypeList = new HashSet<String>(){{
			    add("Car");
			    add("Motorcycle");
			    add("Truck");
			}};
			
			if (!vehicleTypeList.contains(vehicle.getType())) {
				vehicle.setStatus("FAILED");
				vehicle.setComment(
						"VEHICLE TYPE - " + vehicle.getType() + " IS NOT YET AVAILABLE FOR REGISTRATION");
				
				return vehicle;
			}
			
			Integer id = vehicleDAO.getAllVehicles().getVehicleList().size() + 1;
			
			vehicle.setId(id);
			vehicle.setCurrentDate(new Date());
			vehicle.setOwnerName(vehicle.getOwnerName().trim());
			
			vehicleDAO.getAllVehicles().getVehicleList().add(vehicle);
			vehicle.setStatus("SUCCESS");
			vehicle.setComment(
					"VEHICLE WITH LICENSE PLATE - " + vehicle.getLicensePlate() + " IS SUCCESSFULLY REGISTERED.");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			vehicle.setStatus("FAILED");
			vehicle.setComment(
					"VEHICLE WITH LICENSE PLATE - " + vehicle.getLicensePlate() + " IS UNSUCCESSFULLY REGISTERED.");
			e.printStackTrace();
		}
		
		return vehicle;
	}

	@Override
	public Vehicle getVehicleByLicensePlate(String licensePlate) {
		// TODO Auto-generated method stub
		String param = licensePlate.trim();
		
		return vehicleDAO.getVehicleByLicensePlate(param);
	}
	
	private boolean isAlpha(String name) {
	    return name.matches("[a-zA-Z\s]+");
	}
	
	private boolean isValidLicensePlate(String name) {
	    return name.matches("[a-zA-Z0-9\\-]+");
	}
	

}
