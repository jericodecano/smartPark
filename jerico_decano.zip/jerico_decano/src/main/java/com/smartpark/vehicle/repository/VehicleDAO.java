package com.smartpark.vehicle.repository;

import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.smartpark.model.Vehicle;
import com.smartpark.model.Vehicles;

@Repository
public class VehicleDAO {
	
	private static Vehicles list = new Vehicles();
	
	/*static {
		list.getVehicleList().add(
				new Vehicle("MOJ", "VIOS", "OWNER MOJ"));
		
		list.getVehicleList().add(
				new Vehicle("LICENSE DECANO", "TRUCK", "OWNER JEC"));
	}*/

	public Vehicles getAllVehicles() {
		return list;
	}
	
	public void addVehicle(Vehicle vehicle) {
		list.getVehicleList().add(vehicle);
	}
	
	public Vehicle getVehicleByLicensePlate(String licensePlate) {
		Vehicle vehicle = null;
		Optional<Vehicle> tempVehicle = list.getVehicleList().stream()
				.filter(x -> licensePlate.equals(x.getLicensePlate())).findFirst();
		
		if (tempVehicle.isPresent()) {
			vehicle = tempVehicle.get();
		}
		
		return vehicle;
	}
}
