package com.smartpark.vehicle.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartpark.model.Vehicle;
import com.smartpark.model.Vehicles;
import com.smartpark.vehicle.service.VehicleService;

@RestController
@RequestMapping(path = "/vehicle")
public class VehicleApiImpl implements VehicleApi{
	
	@Autowired
	private VehicleService vehicleService;
	
	// Implementing a GET method 
    // to get the list of all 
    // the vehicles
	@Override
	@GetMapping( 
	        path = "/getVehicles", 
	        produces = "application/json")
	public Vehicles getVehicles() {
		return vehicleService.getVehicles();
	}

	// Implementing a POST method 
    // to add to 
    // the vehicles
	@Override
	@PostMapping( 
	        path = "/addVehicle", 
	        consumes = "application/json", 
	        produces = "application/json")
	public Vehicle addVehicle(@RequestBody Vehicle vehicle) {
		// TODO Auto-generated method stub
		
		return vehicleService.addVehicle(vehicle);
	}

	@Override
	@GetMapping( 
	        path = "/getVehicleByLicensePlate/", 
	        produces = "application/json")
	public Vehicle getVehicleByLicensePlate(@RequestParam("licensePlate") String licensePlate) {
		// TODO Auto-generated method stub
		return vehicleService.getVehicleByLicensePlate(licensePlate);
	}
}
