package com.smartpark.vehicle.service;

import com.smartpark.model.Vehicle;
import com.smartpark.model.Vehicles;

public interface VehicleService {

	Vehicles getVehicles();
	
	Vehicle addVehicle(Vehicle vehicle);
	
	Vehicle getVehicleByLicensePlate(String licensePlate);
	
}
