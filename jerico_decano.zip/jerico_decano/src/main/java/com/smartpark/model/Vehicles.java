package com.smartpark.model;

import java.util.ArrayList;
import java.util.List;

public class Vehicles {
	
	private List<Vehicle> vehicleList;

	public List<Vehicle> getVehicleList() {
		if (null == vehicleList) {
			vehicleList = new ArrayList<Vehicle>();
		}
		
		return vehicleList;
	}

	public void setVehicleList(List<Vehicle> vehicleList) {
		this.vehicleList = vehicleList;
	}
}
