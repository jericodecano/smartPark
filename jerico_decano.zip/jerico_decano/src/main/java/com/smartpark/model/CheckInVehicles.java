package com.smartpark.model;

import java.util.ArrayList;
import java.util.List;

public class CheckInVehicles {
	
	private List<CheckInVehicle> checkInVehicleList;

	public List<CheckInVehicle> getCheckInVehicleList() {
		if (null == checkInVehicleList) {
			checkInVehicleList = new ArrayList<CheckInVehicle>();
		}
		
		return checkInVehicleList;
	}

	public void setCheckInVehicleList(List<CheckInVehicle> checkInVehicleList) {
		this.checkInVehicleList = checkInVehicleList;
	}
}
