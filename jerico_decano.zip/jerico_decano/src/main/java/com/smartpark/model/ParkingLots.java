package com.smartpark.model;

import java.util.ArrayList;
import java.util.List;

public class ParkingLots {
	
	private List<ParkingLot> parkingLotList;

	public List<ParkingLot> getParkingLotList() {
		if (null == parkingLotList) {
			parkingLotList = new ArrayList<ParkingLot>();
		}
		
		return parkingLotList;
	}

	public void setParkingLotList(List<ParkingLot> parkingLotList) {
		this.parkingLotList = parkingLotList;
	}
}
