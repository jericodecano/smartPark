package com.smartpark.model;

import java.math.BigDecimal;
import java.util.Date;

public class CheckInVehicle extends CommonProperties{

	private Vehicle vehicle;
	
	private ParkingLot parkingLot;
	
	BigDecimal totalCost;
	
	Integer minutesOfStay;
	
	Date checkIn;
	
	Date checkOut;
	
	Boolean isCheckedOut = false;
	
	public CheckInVehicle(Vehicle vehicle, ParkingLot parkingLot) {
		super();
		this.vehicle = vehicle;
		this.parkingLot = parkingLot;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	public ParkingLot getParkingLot() {
		return parkingLot;
	}

	public void setParkingLot(ParkingLot parkingLot) {
		this.parkingLot = parkingLot;
	}

	public BigDecimal getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(BigDecimal totalCost) {
		this.totalCost = totalCost;
	}

	public Integer getMinutesOfStay() {
		return minutesOfStay;
	}

	public void setMinutesOfStay(Integer minutesOfStay) {
		this.minutesOfStay = minutesOfStay;
	}
	
	public Date getCheckIn() {
		return checkIn;
	}

	public void setCheckIn(Date checkIn) {
		this.checkIn = checkIn;
	}

	public Date getCheckOut() {
		return checkOut;
	}

	public void setCheckOut(Date checkOut) {
		this.checkOut = checkOut;
	}

	public Boolean getIsCheckedOut() {
		return isCheckedOut;
	}

	public void setIsCheckedOut(Boolean isCheckedOut) {
		this.isCheckedOut = isCheckedOut;
	}
}
