
# Smart Park Application

"SmartPark" is a technology company developing an intelligent parking management system for urban areas. The company is aiming to optimize the use of parking spaces and facilitate easy navigation for drivers.
  

## Software Requirements

Language - Java 17

Integrated development environment (IDE) - Eclipse Oxygen www.eclipse.org/oxygen/

Servlet framework - Springboot version 3.3.2 www.spring.io

Postman - www.getpostman.com


## Run the project

To run the project

Open Eclipse and import the project into the workspace

Under the package "com.smartpark", open SmartPark.java

Run SmartPark.java as a "Java Application"

## Requests using Postman

Open postman to make a post/get request.

URL set to: http://localhost:8080/

- Select Body -> raw
- In the "body" tab make a JSON request with the objects found in the models.

Example: http://localhost:8080/checkInOut/checkInVehicle

Example of a body for the request:

{
    "licensePlate": "LICENSE PLATE 1",
    "lotId": "LOT ID 1"
}

Then click the SEND button to perform the request.


## API Reference
http://localhost:8080

#### Registering a Parking Lot

```http
  POST /parkingLot/addParkingLot
```

| Parameter        | Type     | Description                  |

| :--------        | :------- | :-------------------------   |

| `lotId`          | `string` | **Required**. Name of lot id |

| `location`       | `string` | Name of location             |

| `capacity`       | `number` | Capacity of Parking Lot      |

| `occupiedSpaces` | `number` | Current occupied spaces      |

| `costPerMinute`  | `number` | Parking cost per minute      |

#### Registering a Vehicle

```http
  POST /vehicle/addVehicle
```

| Parameter      | Type     | Description                            |

| :--------      | :------- | :-------------------------             |

| `licensePlate` | `string` | **Required**. License plate of vehicle |

| `type`         | `string` | Vehicle type (Car, Motorcycle, Truck)  |

| `ownerName`    | `string` | Letters and spaces only                |

#### Checking in a vehicle to a parking lot

```http
  POST /checkInOut/checkInVehicle
```

| Parameter      | Type     | Description                |

| :--------      | :------- | :------------------------- |

| `licensePlate` | `string` | License plate of vehicle   |

| `lotId`        | `string` | Lot id of parking lot      |

#### Checking out a vehicle from a parking lot and display parking cost 

```http
  POST /checkInOut/checkInOut/checkOutVehicle
```

| Parameter      | Type     | Description                |

| :--------      | :------- | :------------------------- |

| `licensePlate` | `string` | License plate of vehicle   |

#### Viewing current occupancy and availability of a parking lot 

```http
  POST /parkingLot/getParkingLotByLotId
```

| Parameter | Type     | Description                |

| :-------- | :------- | :------------------------- |

| `lotId`   | `string` | Lot id of parking lot      |


#### Viewing all vehicles currently parked in a lot 

```http
  POST /checkInOut/getAllVehiclesInALot
```

| Parameter | Type     | Description                |

| :-------- | :------- | :------------------------- |

| `lotId`   | `string` | Lot id of parking lot      |


